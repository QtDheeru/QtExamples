#ifndef MYIMAGERESPONSE_H
#define MYIMAGERESPONSE_H

#include <QQuickImageResponse>
#include <QDebug>
#include <QThread>
#include <QQuickTextureFactory>
#include <QImage>
#include <QTimer>

class MyImageResponse : public QQuickImageResponse
{
public:
    MyImageResponse();
    MyImageResponse(QString id);
    ~MyImageResponse();

    // QQuickImageResponse interface
public:
    virtual QQuickTextureFactory *textureFactory() const override;

    // QQuickImageResponse interface
    int id() const;
    void setId(int newId);

public slots:
    virtual void cancel() override;


    int m_id;
    int m_originalId;
};

#endif // MYIMAGERESPONSE_H
