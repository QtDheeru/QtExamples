#ifndef PROCESSORIF1REQUEST_H
#define PROCESSORIF1REQUEST_H

#include <QObject>
#include <QDebug>

class ProcessorIF1Request : public QObject
{
    Q_OBJECT
public:
    explicit ProcessorIF1Request(QObject *parent = nullptr);

    int timeout() const;
    void setTimeout(int newTimeout);

public slots :
    void handleRequest(int id);
signals:
    void coverArtReceived(int id);

private :
    int m_timeout;
};

#endif // PROCESSORIF1REQUEST_H
