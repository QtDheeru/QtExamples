#include "MyImageResponse.h"

MyImageResponse::MyImageResponse()
{
    m_id = 0;
    qDebug() << Q_FUNC_INFO << " Constructor " <<Qt::endl;
    QTimer *timer = new QTimer;
    timer->setInterval(100);
    connect(timer,&QTimer::timeout,this,[this,timer](){
        //qDebug() << Q_FUNC_INFO << " Timer expired..."<<Qt::endl;
        emit finished();
        timer->stop();
    });
    //timer->start();
}


MyImageResponse::MyImageResponse(QString id)
{
    qDebug() << Q_FUNC_INFO << " Constructor Id = "<< id <<Qt::endl;
    m_originalId = id.toInt();
    m_id = m_originalId % 255;
    QTimer *timer = new QTimer;
    timer->setInterval(5);
    connect(timer,&QTimer::timeout,this,[this,timer](){
        //qDebug() << Q_FUNC_INFO << " Timer expired..."<<Qt::endl;
        emit finished();
        timer->stop();
    });
    //timer->start();
}

MyImageResponse::~MyImageResponse()
{
    qDebug() << Q_FUNC_INFO << " C++ Destuctior Id = "<< m_originalId  <<Qt::endl;
}

QQuickTextureFactory *MyImageResponse::textureFactory() const
{
        qDebug() << Q_FUNC_INFO << " Request textureFactory received" <<Qt::endl;
        qDebug() << "MyImageResponse Thread ID=" << QThread::currentThreadId() << Qt::endl;
        QImage image(80,80,QImage::Format_RGBA8888);
        QImage im1("://AsyncImageLoading/Car.png");
        if (im1.isNull()){
            qDebug() << " Image is not loaded successfully..."<<Qt::endl;
        }
        image.fill(QColor(m_id,m_id,m_id,255));
        return QQuickTextureFactory::textureFactoryForImage(im1);
}

void MyImageResponse::cancel()
{
    qDebug() << Q_FUNC_INFO << " Request has been cancelled for ID =" << m_originalId <<Qt::endl;
}

int MyImageResponse::id() const
{
    return m_id;
}

void MyImageResponse::setId(int newId)
{
    m_id = newId;
}
