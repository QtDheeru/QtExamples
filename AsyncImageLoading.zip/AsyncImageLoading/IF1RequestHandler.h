#ifndef IF1REQUESTHANDLER_H
#define IF1REQUESTHANDLER_H

#include <QObject>
#include <QQueue>
#include <QDebug>
#include <QPointer>
#include <QMultiMap>
#include "ProcessorIF1Request.h"

class MyImageResponse;

class IF1RequestHandler : public QObject
{
    Q_OBJECT
public:
    explicit IF1RequestHandler(QObject *parent = nullptr);
    void process(MyImageResponse *);
public slots :
    void covertArtReceived(int response);

signals:

private :
//    QQueue<MyImageResponse*>   m_pendingRequests;
//    QQueue<MyImageResponse*>   m_activeQueue;

    QMultiMap<int , MyImageResponse*>   m_pendingRequests;
    QMultiMap<int , MyImageResponse*>   m_activeQueue;

    QPointer<ProcessorIF1Request> m_processor;

};

#endif // IF1REQUESTHANDLER_H
