#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "MyAsyncImageProvider.h"
#include <QThread>
#include <QQmlContext>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    int timeout = QString(argv[1]).toInt();

    MyAsyncImageProvider provider;
    provider.setProperty("timeout",timeout);

    QQmlApplicationEngine engine;
    const QUrl url(u"qrc:/AsyncImageLoading/main.qml"_qs);
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);

    engine.addImageProvider("Dheeru",&provider);
    engine.rootContext()->setContextProperty("imgProvider",&provider);

    qDebug() << "Main Thread ID=" << QThread::currentThreadId() << Qt::endl;

    engine.load(url);

    return app.exec();
}
