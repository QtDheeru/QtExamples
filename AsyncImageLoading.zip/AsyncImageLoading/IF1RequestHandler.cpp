#include "IF1RequestHandler.h"
#include "MyImageResponse.h"

IF1RequestHandler::IF1RequestHandler(QObject *parent)
    : QObject{parent}
{
    qDebug() << Q_FUNC_INFO << Qt::endl;
    m_processor = new ProcessorIF1Request;
    connect(m_processor,&ProcessorIF1Request::coverArtReceived,this,&IF1RequestHandler::covertArtReceived);
}

void IF1RequestHandler::process(MyImageResponse *req)
{
    m_processor->setTimeout(this->property("timeout").toInt());
    qDebug() << Q_FUNC_INFO << " Fetch Cover art from IF1 " << req->id() <<Qt::endl;
    if (m_activeQueue.size() >= 10) {
        qDebug() << Q_FUNC_INFO << "PENGING-Q Active Q Size =" << m_activeQueue.size() << " Pending Q Size =" << m_pendingRequests.size() << " Inserting into Pending Q " << req->id() <<Qt::endl;
        QMultiMap<int , MyImageResponse*>::const_iterator last = m_pendingRequests.end();
        this->m_pendingRequests.insert(last,req->id(),req);
    }else {
        qDebug() << Q_FUNC_INFO << "ACTIVE-Q Active Q Size =" << m_activeQueue.size() << " Pending Q Size =" << m_pendingRequests.size() << " Inserting into Active Q " << req->id() <<Qt::endl;

        QMultiMap<int, MyImageResponse*>::const_iterator last = m_activeQueue.end();
        this->m_activeQueue.insert(last,req->id(),req);
        //TO-DO. Send the request to IF1
        QMetaObject::invokeMethod(m_processor,"handleRequest",Qt::QueuedConnection,Q_ARG(int,req->id()));
    }
}

void IF1RequestHandler::covertArtReceived(int response)
{
    qDebug() << Q_FUNC_INFO << " Covert Art received from IF1 = " << response << Qt::endl;
    int firstKey = this->m_activeQueue.firstKey();
    //if (firstKey == response){
        qDebug() << Q_FUNC_INFO << " Covert Art received for ID =" << response  << " First Element in Q are same." <<Qt::endl;
        MyImageResponse *resp = m_activeQueue.take(firstKey);// Removes the entry from the map also.
        resp->finished();//send signal that process is complete..
    //}
    // Send the first entry from PendingQ
    if (!m_pendingRequests.isEmpty()) {
        int firstPendingRequest = this->m_pendingRequests.firstKey();
        MyImageResponse *resp1 = m_pendingRequests.take(firstPendingRequest);
        QMultiMap<int, MyImageResponse*>::const_iterator last = m_activeQueue.end();
        m_activeQueue.insert(last,resp1->id(),resp1);
        qDebug() << Q_FUNC_INFO << " Send Requests  IF1 ID = " << firstPendingRequest << " for Processing " << Qt::endl;
        QMetaObject::invokeMethod(m_processor,"handleRequest",Qt::QueuedConnection,Q_ARG(int,firstPendingRequest));
    }else {
        qDebug() << Q_FUNC_INFO << " Nothing is pending in Pending Q. Nothing to send" << Qt::endl;
    }
}
