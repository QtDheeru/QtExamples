#include "ProcessorIF1Request.h"
#include <QThread>

ProcessorIF1Request::ProcessorIF1Request(QObject *parent)
    : QObject{parent}
{
      qDebug() << Q_FUNC_INFO << " Data is collected " << Qt::endl;
      this->setTimeout(5);
}

void ProcessorIF1Request::handleRequest(int id)
{
    QThread::msleep(timeout());
    qDebug() << Q_FUNC_INFO << " Fetch Covert from IF1 for ID=" << id  << " Processing Time =" << timeout() << Qt::endl;
    emit coverArtReceived(id);
}

int ProcessorIF1Request::timeout() const
{
    return m_timeout;
}

void ProcessorIF1Request::setTimeout(int newTimeout)
{
    m_timeout = newTimeout;
}
