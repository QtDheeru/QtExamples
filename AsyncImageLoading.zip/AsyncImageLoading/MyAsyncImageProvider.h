#ifndef MYASYNCIMAGEPROVIDER_H
#define MYASYNCIMAGEPROVIDER_H

#include <QQuickAsyncImageProvider>
#include <QDebug>
#include <QThread>
#include "IF1RequestHandler.h"

class MyAsyncImageProvider : public QQuickAsyncImageProvider
{
    Q_OBJECT
public:
    MyAsyncImageProvider();

    // QQuickAsyncImageProvider interface
public:
    virtual QQuickImageResponse *requestImageResponse(const QString &id, const QSize &requestedSize) override;
public slots :
    void stopRequest(int id);
private :
    QThread *m_thread;
    IF1RequestHandler *m_if1ReqHandler;
};

#endif // MYASYNCIMAGEPROVIDER_H
