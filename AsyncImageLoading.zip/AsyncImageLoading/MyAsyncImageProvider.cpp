#include "MyAsyncImageProvider.h"
#include <QDebug>
#include <QThread>
#include "MyImageResponse.h"
#include "IF1RequestHandler.h"

MyAsyncImageProvider::MyAsyncImageProvider()
{
    qDebug() << Q_FUNC_INFO << Qt::endl;
    this->m_thread = new QThread;
    m_thread->start();
    this->m_if1ReqHandler = new IF1RequestHandler;
    m_if1ReqHandler->moveToThread(m_thread);
}

QQuickImageResponse *MyAsyncImageProvider::requestImageResponse(const QString &id, const QSize &requestedSize)
{
        qDebug() << Q_FUNC_INFO << " Id =" << id << " Size =" << requestedSize << Qt::endl;
        qDebug() << "MyAsyncImageProvider Thread ID=" << QThread::currentThreadId() << Qt::endl;
        int timeout = this->property("timeout").toInt();
        m_if1ReqHandler->setProperty("timeout",timeout);
        MyImageResponse *response = new MyImageResponse(id);
        m_if1ReqHandler->process(response);
        return response;
}

void MyAsyncImageProvider::stopRequest(int id)
{
    qDebug() << Q_FUNC_INFO << " Stop Index =" << id << Qt::endl;
}
